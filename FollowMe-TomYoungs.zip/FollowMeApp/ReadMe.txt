Tom Youngs FollowMe App

instructions for play:

Press any key to start the game, then the bots path will be shows to the user.

After the bot has finished the user is shows the starting point, the user can then choose to view the path
by pressing "c". By pressing the arrow keys (pressing tile by tile) the user then has to trace the pattern that 
the bot followed untill it finishes (arrow key must be pressed again to win the stage)

On win screen the user must wait a few seconds till the text appears on the screen and they can move on to the next
stage (pressing any key)

as the levels progress the length of the pattern will increase

at level 5 the grid is changed to be 5x5

at level 10 the grid changes to be 6x6
